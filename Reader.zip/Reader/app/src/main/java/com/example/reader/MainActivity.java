package com.example.reader;

import android.os.Bundle;
import android.util.Log;
import android.util.Size;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.common.Barcode;

public class MainActivity extends AppCompatActivity {


    private static final String SCRIPT_URL = "https://script.google.com/macros/s/AKfycbwoeXc40JN-TASKyd0V5jB4An6DRGHsQoekcFjzNEmvBdhZcKi78VYVIqo-2pIGoRNG/exec";

    private long TimeFromTHeLastScann = 0;
    private PreviewView previewView;
    private ListenableFuture<ProcessCameraProvider> cameraProviderFuture;
    private EditText containerIdInput;
    private Button btnStartCamera;
    private String nrKontenera = "";
    private String lastScannedCode = "";
    private final OkHttpClient httpClient = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.viewFinder);
        containerIdInput = findViewById(R.id.containerIdInput);
        btnStartCamera = findViewById(R.id.btnStartCamera);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnStartCamera.setOnClickListener(v -> {
            nrKontenera = containerIdInput.getText().toString().trim();
            if (!nrKontenera.isEmpty()) {
                btnStartCamera.setVisibility(View.GONE);
                containerIdInput.setVisibility(View.GONE);
                previewView.setVisibility(View.VISIBLE);
                setupCamera();
            } else {
                Toast.makeText(this, "Wpisz numer kontenera!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupCamera() {
        cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                startCamera(cameraProvider); // Tutaj tylko odpalamy kamerę
            } catch (ExecutionException | InterruptedException e) {
                Log.e("CameraX", "Błąd startu kamery: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    @OptIn(markerClass = ExperimentalGetImage.class)
    private void startCamera(@NonNull ProcessCameraProvider cameraProvider) {
        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(previewView.getSurfaceProvider());


        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                        Barcode.FORMAT_CODE_128,
                        Barcode.FORMAT_ALL_FORMATS) // FORMAT_GS1_128 jest częścią Code 128 w ML Kit
                .build();

        BarcodeScanner scanner = BarcodeScanning.getClient(options);

        ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                .setTargetResolution(new Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();

        imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this), imageProxy -> {
            android.media.Image mediaImage = imageProxy.getImage();
            if (mediaImage != null) {
                InputImage image = InputImage.fromMediaImage(mediaImage, imageProxy.getImageInfo().getRotationDegrees());
                scanner.process(image)
                        .addOnSuccessListener(barcodes -> {
                            for (Barcode barcode : barcodes) {
                                // Używamy getDisplayValue(), żeby czytać czysty numer bez technicznych prefiksów
                                String value = barcode.getDisplayValue();
                                if (value == null) value = barcode.getRawValue();

                                if (value != null) {
                                    processAndSend(value);
                                }
                            }
                        })
                        .addOnCompleteListener(task -> imageProxy.close());
            }
        });

        try {
            cameraProvider.unbindAll();
            cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageAnalysis);
        } catch (Exception e) {
            Log.e("CameraX", "Błąd bindowania", e);
        }
    }

    private void processAndSend(String rawValue) {

        String tempKod = rawValue;
        if (rawValue != null && rawValue.startsWith("]C1")) {
            tempKod = rawValue.substring(3);
        }

        // Robimy zmienną FINALNĄ, aby była dostępna wewnątrz Callback i runOnUiThread
        final String czystyKod = tempKod;


        long now = System.currentTimeMillis();
        if (czystyKod.equals(lastScannedCode) && (now - TimeFromTHeLastScann) < 5000) {
            return;
        }

        lastScannedCode = czystyKod;
        TimeFromTHeLastScann = now;


        byte[] bytes = czystyKod.getBytes();
        StringBuilder binary = new StringBuilder();
        for (byte b : bytes) {
            binary.append(String.format("%8s", Integer.toBinaryString(b & 0xFF)).replace(' ', '0')).append(" ");
        }
        String kodBinarny = binary.toString();

        // 4. BUDOWANIE URL
        HttpUrl url = HttpUrl.parse(SCRIPT_URL).newBuilder()
                .addQueryParameter("kontener", nrKontenera)
                .addQueryParameter("kod", kodBinarny)
                .addQueryParameter("raw", czystyKod)
                .build();

        Request request = new Request.Builder().url(url).build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e("GoogleSheets", "Błąd sieci: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {

                    runOnUiThread(() ->
                            Toast.makeText(MainActivity.this, "Zapisano kod: " + czystyKod, Toast.LENGTH_SHORT).show()
                    );
                }
                response.close();
            }
        });
    }
}